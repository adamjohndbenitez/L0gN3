package com.life.logman.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifeLogManSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
