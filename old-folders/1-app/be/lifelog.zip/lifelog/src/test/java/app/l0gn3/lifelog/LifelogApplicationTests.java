package app.l0gn3.lifelog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LifelogApplicationTests {

	@Test
	void contextLoads() {
	}

}
