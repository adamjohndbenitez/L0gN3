package app.l0gn3.lifelog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LifelogApplication {

	public static void main(String[] args) {
		SpringApplication.run(LifelogApplication.class, args);
	}

}
