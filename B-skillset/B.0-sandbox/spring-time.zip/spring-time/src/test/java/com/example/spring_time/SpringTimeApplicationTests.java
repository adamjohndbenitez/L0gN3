package com.example.spring_time;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTimeApplicationTests {

	@Test
	void contextLoads() {
	}

}
